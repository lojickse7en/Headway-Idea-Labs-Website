# Handoff: Headway Idea Labs — Post-Accelerator Program Page

## Overview
A new marketing/landing page for **Headway Idea Labs'** Post-Accelerator Program. It targets accelerators, innovation hubs, and ecosystem partners, positioning Headway's post-program track as the step that moves founders from "graduated" to "investor-ready." The page is to be rebuilt in the client's existing **WordPress + Elementor** site.

## About the design files
The files in this bundle are **design references created in HTML** — a high-fidelity prototype showing the intended look, layout, and behavior. They are **not** production code to paste into WordPress. The task is to **recreate this design in the client's existing Elementor environment**, using its sections, widgets, global fonts/colors, and the site's current header/footer where appropriate.

Two reference files are included:
- `Headway Post-Accelerator Page (standalone).html` — the full page, self-contained (works offline). Open in a browser and use dev tools to inspect any exact value.
- `Headway Post-Accelerator — Build Spec.html` — a formatted spec sheet (tokens, type scale, section-by-section breakdown, Elementor mapping). Open in a browser; print to PDF if needed.

## Fidelity
**High-fidelity.** Colors, typography, spacing, shadows, and interactions are final. Rebuild the UI to match, using Elementor's widgets and the site's global styles. Where the prototype hand-builds a decorative graphic (the hero "Founder Readiness" dashboard), it may be reproduced with Elementor widgets/icons or dropped in as an exported image — visual parity is what matters.

## Getting it into Figma (optional)
If a Figma version is wanted: install the free **html.to.design** browser extension, open `Headway Post-Accelerator Page (standalone).html` in the browser, run the extension, and it imports the page into editable, layered Figma frames (capture desktop at 1440px and mobile at 390px). This works on the local file with no hosting.

## Screens / Views
Single responsive page. Design width **1440px** (desktop) and **390px** (mobile). Content container maxes at **1180px** with 28px side padding (20px mobile). Section vertical padding **84px** (58px mobile). Breakpoints at **980px** (nav → hamburger) and **620px**.

Sections in order (backgrounds alternate white / warm `#FFF9F3`):

1. **Sticky header** — logo left; nav (About, Programs▾, Services▾, Startup Funding▾, Resources▾ with hover dropdowns) center; orange **Login** button right. Collapses to hamburger + slide-in menu < 980px. bg `#FFFFFF`, 1px bottom border `#E7EBF1`, height 78px.
2. **Hero** — bg = `banner.webp` over `#FEF7F0`. Left column: eyebrow "Post-Accelerator Program", H1 ("…move them closer to **investor worthiness.**" — last two words orange), lead paragraph, orange CTA "Schedule Your Free Consultation". Right column: white "Founder Readiness" dashboard card (82% gauge, 3 checklist rows, floating "Capital matched $4.2M" toast). The dashboard is decorative CSS/SVG.
3. **Worksheets** — bg `#FFFFFF`. Centered header "60+ operating worksheets turn advice into **execution.**" + 6 rounded pill chips, each with an orange dot: Investor narrative, Capital roadmap, Milestone tracking, Financial clarity, Accountability rhythm, Pitch proficiency.
4. **End-to-end journey** — bg `#FFF9F3`. Two columns: left = dark navy radial-gradient panel (label "How it all connects", H2 "Where the post-accelerator step fits in the founder journey.", paragraph); right = 4-step vertical stack: 01 Pre-Accelerator Foundation, 02 Accelerator Embedded Curriculum, **03 Post-Accelerator Investor Readiness (featured: orange border, peach tint, "You are here" badge)**, 04 Ecosystem Investor Connection. Step number circles are navy.
5. **Who it's built for** — bg `#FFFFFF`. Centered header "Designed for accelerators, not one-off consulting." + 2 cards (Structured founder development · Lower program burden), each with an orange check icon. Hover: 3px lift + light-blue border `#BCD8F5`.
6. **Why this exists** — bg `#FFF9F3`. Split header (H2 "The missing layer after **demo day.**" left, intro paragraph right) + 3 cards with square icon chips (navy / teal / orange): Programming continuity · Founder transformation · Capital discipline.
7. **Dark CTA band** — rounded box, navy radial gradient with faint network texture. H2 "Let's Build a Founder Journey That Doesn't Stop at Demo Day", paragraph, two buttons: orange "Download Program Overview PDF" + outline "Inquire About Partnership Opportunities". The box is pulled **~150px down so it overlaps the footer** (negative bottom margin + higher z-index).
8. **Footer** — bg `#281F18` (dark brown). Three columns: logo (white) + social icons; nav links; newsletter signup (email input + slate `#4C5B6B` "Sign Up" button). Faint orange/teal arrow motif top-right. Bottom bar: "© 2025 Headway Idea Labs. All rights reserved." + Privacy Policy.

## Interactions & behavior
- **Nav dropdowns:** hover reveals a card menu (fade + 8px rise, .18s).
- **Buttons (primary):** gradient stays on hover; add glow `box-shadow:-2px 23px 89.1px 0 rgba(253,123,3,.349)` + `translateY(-2px)`, .15s.
- **Framework cards (Why this exists / Built for):** hover lifts 3–4px; "Why this exists" mcards are static; the teal-hover treatment (`#40A9C9` fill, white text/icon) is used on the original framework cards — match per the standalone file.
- **Journey steps:** hover lifts 3px with a soft shadow.
- **Pill chips:** hover lifts 2px with an orange-tinted shadow.
- **Mobile menu:** hamburger toggles a full-height slide-in panel; nav groups expand on tap.
- **Responsive:** grids collapse (3→2→1), hero stacks and centers, dark panels lose sticky positioning.

## State management
Effectively static marketing page. Only client-side state is the **mobile menu open/closed** (and per-group expand). No data fetching. Newsletter form posts to whatever the site's email provider uses (placeholder `onsubmit` in the prototype).

## Design tokens
**Fonts:** Poppins (headings, weights 400–800), Open Sans (body, 400–700) — Google Fonts.

**Colors:**
- Navy `#0E2A4D` — headings, nav text, step circles
- Orange `#F5841F` — accents, eyebrows, links, icon strokes (`#FD7900`→`#F8B170` in the button gradient)
- Teal `#40A9C9` — card hover fill + "Founder transformation" chip
- Footer brown `#281F18`
- Newsletter button slate `#4C5B6B`
- Success green `#1F8A5B` — hero dashboard "Live"/checks
- Ink `#2A3342`, Muted `#5B6676`, Line `#E7EBF1`
- Backgrounds: white `#FFFFFF`, warm `#FFF9F3`, hero peach `#FEF7F0`

**Button gradient:** `linear-gradient(95.4deg, #FD7900 63%, #F8B170 100%)`
**Button hover glow:** `-2px 23px 89.1px 0 rgba(253,123,3,.349)`

**Spacing / radius:** container 1180px; section padding 84px (58px mobile); card radius 14–16px, dark panels 20px, hero dash 24px; grid gap 26px (40–64px for 2-col splits).

**Breakpoints:** 980px (nav collapse), 620px (single-column).

## Assets
Only **two image files** — both already exist in the client's WordPress media library:
- Hero banner: `headwayidealabs.io/wp-content/uploads/2025/09/banner.webp`
- Logo (header + footer): `headwayidealabs.io/wp-content/uploads/2024/06/Headway-Idea-Labs-Logo.png` (footer uses it white via `filter:brightness(0) invert(1)`)

Everything else (the readiness gauge, journey steps, all icons, check marks, social icons, footer arrow motif, CTA network texture) is **inline SVG or pure CSS** in the reference files — copy the SVG markup directly or rebuild with Elementor icons. Nothing to export.

## Files
- `Headway Post-Accelerator Page (standalone).html` — full self-contained page (source of truth; inspect exact values here).
- `Headway Post-Accelerator — Build Spec.html` — formatted spec sheet.
- `Post Accelerator Page.html` — the editable source (external font/image links; lives in the project root).

## Copy reference
All final copy is in the standalone HTML. Headlines per section are listed above; body copy can be lifted verbatim from the reference file.
